import { useColorScheme } from 'react-native';

export const useTheme = () => {
  const colorScheme = useColorScheme();
  const isDark = colorScheme === 'dark';

  return {
    colors: {
      primary: isDark ? '#6E78FE' : '#5A67D8',
      primaryLight: isDark ? '#8B94FF' : '#7C89E8',
      primaryDark: isDark ? '#5762E0' : '#4A56C0',
      
      background: isDark ? '#0c0c10' : '#FFFFFF',
      surface: isDark ? '#1a1a24' : '#F7F9FC',
      card: isDark ? '#252532' : '#FFFFFF',
      
      text: isDark ? '#FFFFFF' : '#1A202C',
      textSecondary: isDark ? '#A0AEC0' : '#718096',
      textTertiary: isDark ? '#718096' : '#A0AEC0',
      
      border: isDark ? '#2D3748' : '#E2E8F0',
      borderLight: isDark ? '#1a1a24' : '#F7F9FC',
      
      success: isDark ? '#48BB78' : '#38A169',
      warning: isDark ? '#ECC94B' : '#D69E2E',
      error: isDark ? '#F56565' : '#E53E3E',
      info: isDark ? '#4299E1' : '#3182CE',
      
      shadow: isDark ? 'rgba(0, 0, 0, 0.5)' : 'rgba(0, 0, 0, 0.1)',
      overlay: isDark ? 'rgba(0, 0, 0, 0.7)' : 'rgba(0, 0, 0, 0.5)',
    },
    spacing: {
      xs: 4,
      sm: 8,
      md: 16,
      lg: 24,
      xl: 32,
      xxl: 48,
    },
    borderRadius: {
      sm: 8,
      md: 12,
      lg: 16,
      xl: 20,
      full: 9999,
    },
    fontSize: {
      xs: 12,
      sm: 14,
      md: 16,
      lg: 18,
      xl: 24,
      xxl: 32,
    },
    fontWeight: {
      normal: '400' as const,
      medium: '500' as const,
      semibold: '600' as const,
      bold: '700' as const,
    },
  };
};

export type Theme = ReturnType<typeof useTheme>;
