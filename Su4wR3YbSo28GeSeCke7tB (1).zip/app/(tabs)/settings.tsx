import React from 'react';
import { View, Text, StyleSheet, ScrollView, Pressable, Linking, AccessibilityInfo } from 'react-native';
import { MaterialCommunityIcons } from '@expo/vector-icons';
import { useTheme } from '@/constants/theme';
import { useSafeAreaInsets } from 'react-native-safe-area-context';

export default function SettingsScreen() {
  const theme = useTheme();
  const insets = useSafeAreaInsets();

  const handlePress = (label: string) => {
    AccessibilityInfo.announceForAccessibility(`${label} selected`);
  };

  const settingsSections = [
    {
      title: 'Accessibility',
      items: [
        {
          icon: 'eye',
          label: 'Screen Reader',
          value: 'Optimized',
          onPress: () => handlePress('Screen Reader'),
        },
        {
          icon: 'format-size',
          label: 'Text Size',
          value: 'Default',
          onPress: () => handlePress('Text Size'),
        },
        {
          icon: 'contrast-circle',
          label: 'High Contrast',
          value: 'Off',
          onPress: () => handlePress('High Contrast'),
        },
      ],
    },
    {
      title: 'About',
      items: [
        {
          icon: 'information',
          label: 'Version',
          value: '1.0.0',
          onPress: () => handlePress('Version'),
        },
        {
          icon: 'shield-check',
          label: 'Privacy Policy',
          onPress: () => {
            AccessibilityInfo.announceForAccessibility('Opening privacy policy');
          },
        },
        {
          icon: 'file-document',
          label: 'Terms of Service',
          onPress: () => {
            AccessibilityInfo.announceForAccessibility('Opening terms of service');
          },
        },
      ],
    },
  ];

  return (
    <View style={[styles.container, { backgroundColor: theme.colors.background }]}>
      <ScrollView 
        style={{ paddingTop: insets.top }}
        contentContainerStyle={styles.scrollContent}
      >
        <View style={styles.header}>
          <Text style={[styles.title, { color: theme.colors.text }]} accessibilityRole="header">
            Settings
          </Text>
        </View>

        {settingsSections.map((section, sectionIndex) => (
          <View key={sectionIndex} style={styles.section}>
            <Text 
              style={[styles.sectionTitle, { color: theme.colors.textSecondary }]}
              accessibilityRole="header"
            >
              {section.title}
            </Text>
            <View style={[styles.card, { backgroundColor: theme.colors.card, borderColor: theme.colors.border }]}>
              {section.items.map((item, itemIndex) => (
                <Pressable
                  key={itemIndex}
                  onPress={item.onPress}
                  accessibilityRole="button"
                  accessibilityLabel={item.label}
                  accessibilityHint={item.value ? `Current value: ${item.value}` : undefined}
                  style={({ pressed }) => [
                    styles.item,
                    itemIndex !== section.items.length - 1 && styles.itemBorder,
                    itemIndex !== section.items.length - 1 && { borderBottomColor: theme.colors.border },
                    { opacity: pressed ? 0.7 : 1 },
                  ]}
                >
                  <View style={styles.itemLeft}>
                    <MaterialCommunityIcons
                      name={item.icon as any}
                      size={24}
                      color={theme.colors.primary}
                      accessibilityElementsHidden
                    />
                    <Text style={[styles.itemLabel, { color: theme.colors.text }]}>
                      {item.label}
                    </Text>
                  </View>
                  <View style={styles.itemRight}>
                    {item.value && (
                      <Text style={[styles.itemValue, { color: theme.colors.textSecondary }]}>
                        {item.value}
                      </Text>
                    )}
                    <MaterialCommunityIcons
                      name="chevron-right"
                      size={20}
                      color={theme.colors.textTertiary}
                      accessibilityElementsHidden
                    />
                  </View>
                </Pressable>
              ))}
            </View>
          </View>
        ))}

        <View style={styles.footer}>
          <Text style={[styles.footerText, { color: theme.colors.textTertiary }]}>
            PB Tech - Powered by OnSpace AI
          </Text>
        </View>
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  scrollContent: {
    paddingBottom: 32,
  },
  header: {
    paddingHorizontal: 16,
    paddingTop: 16,
    paddingBottom: 24,
  },
  title: {
    fontSize: 32,
    fontWeight: '700',
  },
  section: {
    marginBottom: 24,
  },
  sectionTitle: {
    fontSize: 13,
    fontWeight: '600',
    textTransform: 'uppercase',
    letterSpacing: 0.5,
    paddingHorizontal: 16,
    marginBottom: 8,
  },
  card: {
    marginHorizontal: 16,
    borderRadius: 12,
    borderWidth: 1,
    overflow: 'hidden',
  },
  item: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingVertical: 16,
    paddingHorizontal: 16,
    minHeight: 60,
  },
  itemBorder: {
    borderBottomWidth: 1,
  },
  itemLeft: {
    flexDirection: 'row',
    alignItems: 'center',
    flex: 1,
  },
  itemLabel: {
    fontSize: 16,
    fontWeight: '500',
    marginLeft: 12,
  },
  itemRight: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  itemValue: {
    fontSize: 14,
    marginRight: 8,
  },
  footer: {
    alignItems: 'center',
    paddingTop: 24,
  },
  footerText: {
    fontSize: 12,
  },
});
