import React, { useState, useRef } from 'react';
import { View, Text, StyleSheet, ScrollView, TextInput, Pressable, ActivityIndicator, AccessibilityInfo, Platform } from 'react-native';
import { useLocalSearchParams, Stack } from 'expo-router';
import { MaterialCommunityIcons } from '@expo/vector-icons';
import { useTheme } from '@/constants/theme';
import { AI_TOOLS } from '@/constants/aiTools';
import { aiService } from '@/services/aiService';
import * as ImagePicker from 'expo-image-picker';
import * as DocumentPicker from 'expo-document-picker';
import { useAlert } from '@/template';

export default function ToolScreen() {
  const { toolId } = useLocalSearchParams<{ toolId: string }>();
  const theme = useTheme();
  const { showAlert } = useAlert();
  const [input, setInput] = useState('');
  const [output, setOutput] = useState('');
  const [loading, setLoading] = useState(false);
  const [selectedFile, setSelectedFile] = useState<string | null>(null);
  const scrollViewRef = useRef<ScrollView>(null);

  const tool = AI_TOOLS.find((t) => t.id === toolId);

  if (!tool) {
    return (
      <View style={[styles.container, { backgroundColor: theme.colors.background }]}>
        <Text style={{ color: theme.colors.text }}>Tool not found</Text>
      </View>
    );
  }

  const requiresImage = ['image-description', 'ocr', 'video-analysis', 'logo-designer'].includes(tool.id);
  const requiresAudio = ['audio-transcribe', 'voice-conversation', 'voice-clone'].includes(tool.id);

  const handlePickImage = async () => {
    const { status } = await ImagePicker.requestMediaLibraryPermissionsAsync();
    if (status !== 'granted') {
      showAlert('Permission Required', 'We need camera roll permissions to select images');
      return;
    }

    const result = await ImagePicker.launchImageLibraryAsync({
      mediaTypes: ['images'],
      allowsEditing: true,
      quality: 1,
    });

    if (!result.canceled) {
      setSelectedFile(result.assets[0].uri);
      AccessibilityInfo.announceForAccessibility('Image selected');
    }
  };

  const handlePickAudio = async () => {
    const result = await DocumentPicker.getDocumentAsync({
      type: 'audio/*',
    });

    if (!result.canceled) {
      setSelectedFile(result.assets[0].uri);
      AccessibilityInfo.announceForAccessibility('Audio file selected');
    }
  };

  const getSystemPrompt = (): string => {
    const prompts: Record<string, string> = {
      'image-description': 'Provide a detailed, comprehensive description of the image, including all visible elements, colors, composition, and context.',
      'ocr': 'Extract all text visible in the image and present it in a clean, readable format.',
      'translation': 'Translate the provided text accurately while preserving tone and context.',
      'sentiment': 'Analyze the sentiment and emotional tone of the text. Provide detailed insights about emotions, tone, and underlying feelings.',
      'summarizer': 'Create a concise summary of the text, capturing all key points and main ideas.',
      'grammar': 'Check and correct all grammar, spelling, and punctuation errors. Explain the corrections made.',
      'code-explainer': 'Explain the code in detail, covering what it does, how it works, and any important concepts.',
      'math-solver': 'Solve the mathematical problem step-by-step, showing all work and explaining each step.',
      'recipe-generator': 'Create a delicious recipe using the provided ingredients. Include steps, cooking time, and serving size.',
      'story-writer': 'Write an engaging creative story based on the given prompt or theme.',
      'poem-generator': 'Create a beautiful poem based on the theme or topic provided.',
      'email-writer': 'Draft a professional email based on the given context and purpose.',
      'resume-builder': 'Generate professional resume content for the specified role or experience.',
      'qa': 'Provide a comprehensive, accurate answer to the question asked.',
      'social-media': 'Create an engaging social media post that captures attention and encourages interaction.',
      'product-description': 'Write a compelling product description that highlights features and benefits.',
      'video-script': 'Write an engaging video script with clear structure, dialogue, and scene descriptions.',
      'music-creator': 'Describe a musical composition based on the theme, mood, and style requested.',
      'text-to-speech': 'Convert the text to a natural-sounding speech script with proper intonation markers.',
      'voice-conversation': 'Engage in a natural, helpful conversation as an AI assistant.',
    };

    return prompts[tool.id] || 'You are a helpful AI assistant specialized in this task.';
  };

  const handleProcess = async () => {
    if (!input.trim() && !selectedFile) {
      showAlert('Input Required', 'Please enter text or select a file');
      return;
    }

    setLoading(true);
    AccessibilityInfo.announceForAccessibility('Processing your request');

    try {
      let result;

      if (requiresImage && selectedFile) {
        result = await aiService.analyzeImage(selectedFile, input || getSystemPrompt());
      } else if (requiresAudio && selectedFile) {
        result = await aiService.transcribeAudio(selectedFile);
      } else {
        result = await aiService.chat(input, getSystemPrompt());
      }

      if (result.error) {
        showAlert('Error', result.error);
        setOutput('');
      } else {
        setOutput(result.data || 'No response generated');
        AccessibilityInfo.announceForAccessibility('Result ready');
        setTimeout(() => {
          scrollViewRef.current?.scrollToEnd({ animated: true });
        }, 100);
      }
    } catch (error) {
      showAlert('Error', 'An unexpected error occurred');
      setOutput('');
    } finally {
      setLoading(false);
    }
  };

  return (
    <>
      <Stack.Screen 
        options={{ 
          headerTitle: tool.name,
          headerTitleStyle: { color: theme.colors.text },
          headerStyle: { backgroundColor: theme.colors.card },
        }} 
      />
      <View style={[styles.container, { backgroundColor: theme.colors.background }]}>
        <ScrollView 
          ref={scrollViewRef}
          contentContainerStyle={styles.scrollContent}
          keyboardShouldPersistTaps="handled"
        >
          {/* Tool Info */}
          <View 
            style={[styles.toolInfo, { backgroundColor: theme.colors.surface }]}
            accessible
            accessibilityRole="text"
          >
            <MaterialCommunityIcons
              name={tool.icon}
              size={40}
              color={theme.colors.primary}
              accessibilityElementsHidden
            />
            <Text style={[styles.toolDescription, { color: theme.colors.textSecondary }]}>
              {tool.description}
            </Text>
          </View>

          {/* File Picker */}
          {(requiresImage || requiresAudio) && (
            <Pressable
              onPress={requiresImage ? handlePickImage : handlePickAudio}
              accessibilityRole="button"
              accessibilityLabel={requiresImage ? 'Select image' : 'Select audio file'}
              accessibilityHint={selectedFile ? 'File selected, tap to change' : 'No file selected'}
              style={({ pressed }) => [
                styles.filePicker,
                { 
                  backgroundColor: theme.colors.card,
                  borderColor: theme.colors.border,
                  opacity: pressed ? 0.7 : 1,
                },
              ]}
            >
              <MaterialCommunityIcons
                name={requiresImage ? 'image-plus' : 'music'}
                size={24}
                color={theme.colors.primary}
                accessibilityElementsHidden
              />
              <Text style={[styles.filePickerText, { color: theme.colors.text }]}>
                {selectedFile ? '✓ File Selected' : `Select ${requiresImage ? 'Image' : 'Audio'}`}
              </Text>
            </Pressable>
          )}

          {/* Input */}
          <View style={styles.inputSection}>
            <Text 
              style={[styles.label, { color: theme.colors.text }]}
              accessibilityRole="header"
            >
              Input
            </Text>
            <TextInput
              style={[
                styles.input,
                { 
                  backgroundColor: theme.colors.card,
                  color: theme.colors.text,
                  borderColor: theme.colors.border,
                },
              ]}
              placeholder={`Enter ${requiresImage ? 'additional instructions (optional)' : 'your text here'}...`}
              placeholderTextColor={theme.colors.textSecondary}
              multiline
              value={input}
              onChangeText={setInput}
              accessibilityLabel="Input text"
              accessibilityHint="Enter the text you want to process"
            />
          </View>

          {/* Process Button */}
          <Pressable
            onPress={handleProcess}
            disabled={loading}
            accessibilityRole="button"
            accessibilityLabel="Process"
            accessibilityHint="Process your input with AI"
            accessibilityState={{ disabled: loading }}
            style={({ pressed }) => [
              styles.button,
              { 
                backgroundColor: loading ? theme.colors.textTertiary : theme.colors.primary,
                opacity: pressed ? 0.8 : 1,
              },
            ]}
          >
            {loading ? (
              <ActivityIndicator color="#FFFFFF" />
            ) : (
              <>
                <MaterialCommunityIcons 
                  name="rocket-launch" 
                  size={20} 
                  color="#FFFFFF" 
                  accessibilityElementsHidden
                />
                <Text style={styles.buttonText}>Process</Text>
              </>
            )}
          </Pressable>

          {/* Output */}
          {output !== '' && (
            <View style={styles.outputSection}>
              <Text 
                style={[styles.label, { color: theme.colors.text }]}
                accessibilityRole="header"
              >
                Result
              </Text>
              <View 
                style={[
                  styles.output,
                  { 
                    backgroundColor: theme.colors.card,
                    borderColor: theme.colors.border,
                  },
                ]}
                accessible
                accessibilityRole="text"
                accessibilityLabel="AI result"
              >
                <Text style={[styles.outputText, { color: theme.colors.text }]}>
                  {output}
                </Text>
              </View>
            </View>
          )}
        </ScrollView>
      </View>
    </>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  scrollContent: {
    padding: 16,
  },
  toolInfo: {
    padding: 20,
    borderRadius: 16,
    alignItems: 'center',
    marginBottom: 24,
  },
  toolDescription: {
    fontSize: 16,
    textAlign: 'center',
    marginTop: 12,
    lineHeight: 24,
  },
  filePicker: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    padding: 16,
    borderRadius: 12,
    borderWidth: 2,
    borderStyle: 'dashed',
    marginBottom: 24,
    minHeight: 60,
  },
  filePickerText: {
    fontSize: 16,
    fontWeight: '600',
    marginLeft: 12,
  },
  inputSection: {
    marginBottom: 24,
  },
  label: {
    fontSize: 16,
    fontWeight: '600',
    marginBottom: 12,
  },
  input: {
    borderWidth: 1,
    borderRadius: 12,
    padding: 16,
    fontSize: 16,
    minHeight: 120,
    textAlignVertical: 'top',
  },
  button: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    padding: 16,
    borderRadius: 12,
    marginBottom: 24,
    minHeight: 56,
  },
  buttonText: {
    color: '#FFFFFF',
    fontSize: 16,
    fontWeight: '600',
    marginLeft: 8,
  },
  outputSection: {
    marginBottom: 24,
  },
  output: {
    borderWidth: 1,
    borderRadius: 12,
    padding: 16,
    minHeight: 120,
  },
  outputText: {
    fontSize: 16,
    lineHeight: 24,
  },
});
